class LoginManager:
    def validate(self,user):
        if user==None:
            return False
        return True

    def authenticate(self,user):
        return self.validate(user)

def unused_helper():
    return 42
