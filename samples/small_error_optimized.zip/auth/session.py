class SessionManager:
    def create(self):
        token='abc'
        return token

    def destroy(self):
        return True
