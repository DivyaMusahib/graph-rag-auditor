class InvoiceManager:
    def total(self,items):
        s=0
        for x in items:s+=x
        return s

    def average(self,items):
        return self.total(items)/len(items)
