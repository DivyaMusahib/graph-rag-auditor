class PaymentManager:
    def process(self,amount):
        try:return amount/0
        except:return None

    def refund(self,amount):
        return amount
