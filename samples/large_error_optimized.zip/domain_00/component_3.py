class Component3:
    def load(self,data):
        c={}
        for item in data:c[str(item)]=item
        return c

    def search(self,data,target):
        for x in data:
            for y in data:
                if x==target:return x
        return None

    def execute(self,user_input):
        query="SELECT * FROM users WHERE id='"+str(user_input)+"'"
        return query

def duplicate_logic_a(values):
    t=0
    for v in values:t+=v
    return t

def duplicate_logic_b(values):
    t=0
    for v in values:t+=v
    return t
