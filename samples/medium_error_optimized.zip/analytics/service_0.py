class Service0:
    def method_a(self,data):
        r=[]
        for x in data:
            for y in data:
                if x==y:r.append(x)
        return r

    def method_b(self,v):
        try:return 100/v
        except:return 0
